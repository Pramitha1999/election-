<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>මෙතෙක් ප්‍රකාශිත ඡන්ද ප්‍රථිපල අනුව</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('C:/Users/dananjaya/Music/නෙත්/ABC/image PRE/1.13.jpg'); /* Replace with the correct image path */
            background-size: cover;   /* Ensure the background image covers the whole page */
            background-position: center;  /* Center the background image */
            background-repeat: no-repeat; /* Prevent the background from repeating */
            background-attachment: fixed; /* Make the background stay in place when scrolling */
            color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .org-pre-logo{
             position: absolute;
             top: 20px;
             left: 20px;
             width: 150px; /* Adjust the size as needed */
             height: auto;
             z-index: 1000; /* Ensure it's above other elements */
        }

        .org-logo{ 
            position: absolute;
            top: 20px;
            right: 20px;
            width: 110px; /* Adjust the size as needed */
            height: auto;
            z-index: 1000; /* Ensure it's above other elements */
        }

        h1 {
            text-align: center;
            margin-bottom: 35px;
            color: #ffffff;
            font-size: 30;
        }

        .container {
            width: 80%;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .results-section {
            width: 100%;
            background-color: transparent;
        }

        .result {
            margin: 20px 0;
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
            background-color: #2C3E50;
            border-radius: 15px;
            padding: 20px;
            width: 100%;
        }

        .candidate-logo {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 20px;
        }

        .candidate-details {
            flex-grow: 1;
            color: #ffffff;
            text-align: left;
        }

        .candidate-name {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .candidate-votes {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .progress-bar-container {
            width: 40%;
            height: 30px;
            background: #ddd;
            border-radius: 15px;
            position: relative;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            border-radius: 15px;
            background: linear-gradient(to right, rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0));
            box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
            transition: width 0.5s ease-in-out;
        }

        .link-section {
            margin-top: 40px;
        }

        .link-section h2 {
            color: #ffffff;
        }

        .link-section a {
            color: #FFCC00;
            text-decoration: none;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <h1>මෙතෙක් ප්‍රකාශිත ඡන්ද ප්‍රථිපල අනුව</h1>

    <header>
        <img src="C:\Users\dananjaya\Music\නෙත්\ABC\image PRE\nethlogo.png" alt="Organization Logo" class="org-logo">
    </header>

    <header></header>
        <img src="C:\Users\dananjaya\Music\නෙත්\ABC\image PRE\President.jpg" alt="Organization President Logo" class="org-pre-logo">
    </header>


    <div class="container">
        <div class="results-section">
            <div id="results"></div>
        </div>
    </div>

    </a>
    </div>

<script>
  window.addEventListener("DOMContentLoaded", function() {
    // Retrieve the candidate data from localStorage
    const candidates = JSON.parse(localStorage.getItem("candidates"));

    if (!candidates) {
        console.error("No candidates found in localStorage.");
        return;
    }

    // Sort candidates by votes in descending order
    candidates.sort((a, b) => b.votes - a.votes);

    // Function to create a live updating cylindrical progress bar
    function updateProgress(candidate) {
        const result = document.createElement("div");
        result.classList.add("result");

        const img = document.createElement("img");
        img.src = candidate.logoDataURL;
        img.classList.add("candidate-logo");

        const candidateDetails = document.createElement("div");
        candidateDetails.classList.add("candidate-details");

        const candidateName = document.createElement("div");
        candidateName.classList.add("candidate-name");
        candidateName.textContent = candidate.name;

        const candidateVotes = document.createElement("div");
        candidateVotes.classList.add("candidate-votes");
        candidateVotes.innerHTML = `Votes: ${candidate.votes} <br> Percentage: ${candidate.percentage}%`;

        candidateDetails.appendChild(candidateName);
        candidateDetails.appendChild(candidateVotes);

        const progressBarContainer = document.createElement("div");
        progressBarContainer.classList.add("progress-bar-container");

        const progressBar = document.createElement("div");
        progressBar.classList.add("progress-bar");
        progressBar.style.width = '0%';
        progressBar.style.backgroundColor = candidate.color;

        progressBarContainer.appendChild(progressBar);
        result.appendChild(img);
        result.appendChild(candidateDetails);
        result.appendChild(progressBarContainer);

        document.getElementById("results").appendChild(result);

        let currentWidth = 0;
        const targetWidth = candidate.percentage;
        const interval = setInterval(() => {
            if (currentWidth <= targetWidth) {
                progressBar.style.width = currentWidth + '%';
                currentWidth++;
            } else {
                clearInterval(interval);
            }
        }, 20);
    }

    candidates.forEach((candidate, index) => {
        setTimeout(() => {
            updateProgress(candidate);
        }, 1000 * index);
    });
});

</script>
</body>
</html>


    <!-- Add a link to your website 
    <div class="link-section">
        <h2>Visit our live website</h2>
        <a href="https://nethnews.lk/category/19" target="_blank">Click here to view live results</a-->
