<?php
// Your connection code here (from the above example)

// Fetch candidates from the database
$sql = "SELECT * FROM candidates";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Name: " . $row["name"]. " - Votes: " . $row["votes"]. "<br>";
    }
} else {
    echo "0 results";
}

// Close the connection
$conn->close();
?>
