<?php
$servername = "localhost";
$username = "root"; // Adjust if needed
$password = "root123"; // Adjust if needed
$dbname = "election2024"; // Database name created in phpMyAdmin

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare to handle form data from `Untitled-1.html`
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Array to hold candidate data
    $candidates = [];
    
    for ($i = 1; $i <= 5; $i++) { // Assuming 5 candidates
        $name = $_POST["name$i"];
        $votes = $_POST["votes$i"];
        $percentage = $_POST["percentage$i"];
        $color = $_POST["color$i"];

        // Handle logo file upload (if present)
        if (isset($_FILES["logo$i"]["tmp_name"]) && $_FILES["logo$i"]["tmp_name"] != "") {
            $logo = file_get_contents($_FILES["logo$i"]["tmp_name"]);
            $logo = $conn->real_escape_string($logo); // Escape binary data for SQL
        } else {
            $logo = NULL;
        }

        // Insert the candidate into the database
        $sql = "INSERT INTO candidates (name, votes, percentage, color, logo) 
                VALUES ('$name', $votes, $percentage, '$color', '$logo')";
        
        if ($conn->query($sql) === TRUE) {
            echo "Candidate $i added successfully.<br>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
        }
    }
}

$conn->close();
?>
