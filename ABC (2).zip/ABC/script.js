document.getElementById("candidateForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission

    const candidates = [];
    const totalCandidates = 5; // Adjust this if you have more or fewer candidates
    const fileReadPromises = [];

    function readFile(file) {
        return new Promise((resolve, reject) => {
            if (!file) {
                resolve(""); // No file selected
            } else {
                const reader = new FileReader();
                reader.onload = function(event) {
                    resolve(event.target.result); // Base64 file data
                };
                reader.onerror = reject;
                reader.readAsDataURL(file);
            }
        });
    }

    for (let i = 1; i <= totalCandidates; i++) {
        const nameElement = document.getElementById(`name${i}`);
        const votesElement = document.getElementById(`votes${i}`);
        const percentageElement = document.getElementById(`percentage${i}`);
        const colorElement = document.getElementById(`color${i}`);
        const logoElement = document.getElementById(`logo${i}`);

        const candidate = {
            name: nameElement.value,
            votes: parseInt(votesElement.value),
            percentage: parseFloat(percentageElement.value),
            color: colorElement.value
        };

        const filePromise = readFile(logoElement.files[0]).then((logoDataURL) => {
            candidate.logoDataURL = logoDataURL;
        });

        fileReadPromises.push(filePromise);
        candidates.push(candidate);
    }

    // Wait for all file reading to complete
    Promise.all(fileReadPromises).then(() => {
        // Save candidates data to localStorage
        localStorage.setItem("candidates", JSON.stringify(candidates));

        // Redirect to the results page (optional)
        window.location.href = "results.html";
    }).catch((error) => {
        console.error("Error reading file:", error);
    });
});
